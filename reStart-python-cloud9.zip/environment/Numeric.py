print("Python has three numeric types: int, float, and complex")
myvalue=19
print(type(myvalue))
print(str(myvalue) + " is of the data type " + str(type(myvalue)))
firstString = "water"
secondString = "fall"
thirdString = firstString + secondString
print(thirdString)
color = input("What is your favorite color?  ")
animal = input("What is your favorite animal?  ")
print("you like a {} {}!".format(color,animal))